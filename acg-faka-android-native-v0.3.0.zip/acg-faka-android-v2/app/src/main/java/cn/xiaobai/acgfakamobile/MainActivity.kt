package cn.xiaobai.acgfakamobile

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

private const val VERSION_NAME = "0.3.0"
private const val VERSION_CODE = 3

private class NeedTotpException(message: String) : Exception(message)

private data class Module(val title: String, val endpoint: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val plugin: Boolean = false)
private val modules = listOf(
    Module("插件管理", "/admin/api/plugin/getPlugins", Icons.Default.Extension, true),
    Module("订单管理", "/admin/api/order/data", Icons.Default.ReceiptLong),
    Module("商品管理", "/admin/api/commodity/data", Icons.Default.Inventory2),
    Module("卡密管理", "/admin/api/card/data", Icons.Default.Key),
    Module("用户管理", "/admin/api/user/data", Icons.Default.People),
    Module("操作日志", "/admin/api/log/data", Icons.Default.Article)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AcgFakaApp() } }
    }
}

private object AcgApi {
    private val cookieJar = object : CookieJar {
        private val store = mutableMapOf<String, List<Cookie>>()
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            synchronized(store) {
                val existing = store[url.host].orEmpty().filter { old -> cookies.none { it.name == old.name } }
                store[url.host] = existing + cookies.filter { it.expiresAt >= System.currentTimeMillis() }
            }
        }
        override fun loadForRequest(url: HttpUrl): List<Cookie> = synchronized(store) {
            store[url.host].orEmpty().filter { it.matches(url) && it.expiresAt >= System.currentTimeMillis() }
        }
        fun clear() = synchronized(store) { store.clear() }
    }
    private val client = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .callTimeout(25, TimeUnit.SECONDS)
        .followRedirects(false)
        .build()

    fun clearSession() = cookieJar.clear()

    private fun base(input: String): String {
        val clean = input.trim().trimEnd('/')
        val uri = URI(clean)
        require(uri.scheme.equals("https", true)) { "为了保护管理员账号，服务器地址必须使用 HTTPS" }
        require(!uri.host.isNullOrBlank() && uri.userInfo == null && uri.query == null && uri.fragment == null) { "服务器地址格式不正确，请只填写 https://域名" }
        return clean
    }

    suspend fun captcha(server: String): ByteArray = withContext(Dispatchers.IO) {
        val url = base(server) + "/user/captcha/image?action=adminLogin&t=" + System.currentTimeMillis()
        val req = Request.Builder().url(url).header("Accept", "image/*").build()
        client.newCall(req).execute().use { response ->
            if (!response.isSuccessful) error("验证码请求失败：HTTP ${response.code}")
            response.body?.bytes() ?: error("服务器未返回验证码图片")
        }
    }

    suspend fun login(server: String, username: String, password: String, captcha: String, code: String): String = withContext(Dispatchers.IO) {
        val body = FormBody.Builder()
            .add("username", username.trim())
            .add("password", password)
            .add("captcha", captcha.trim())
            .add("remember", "1")
            .apply { if (code.isNotBlank()) add("code", code.trim()) }
            .build()
        val req = Request.Builder().url(base(server) + "/admin/api/authentication/login")
            .post(body).header("Accept", "application/json").build()
        client.newCall(req).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val json = runCatching { JSONObject(text) }.getOrNull() ?: error("登录接口返回非 JSON：HTTP ${response.code}")
            if (json.optInt("code", -1) == 42001) throw NeedTotpException(json.optString("msg", "请输入谷歌两步验证码，并重新输入图形验证码。"))
            if (json.optInt("code", -1) != 200) error(json.optString("msg", "登录失败"))
            "登录成功，服务器已建立管理员会话。"
        }
    }

    suspend fun get(server: String, path: String): JSONObject = request(server, path, null)
    suspend fun post(server: String, path: String, params: Map<String, String>): JSONObject {
        val builder = FormBody.Builder()
        params.forEach { (k, v) -> builder.add(k, v) }
        return request(server, path, builder.build())
    }
    private suspend fun request(server: String, path: String, body: FormBody?): JSONObject = withContext(Dispatchers.IO) {
        val requestBuilder = Request.Builder().url(base(server) + path).header("Accept", "application/json")
        if (body != null) requestBuilder.post(body) else requestBuilder.get()
        client.newCall(requestBuilder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (response.code == 301 || response.code == 302 || response.code == 303) error("服务器要求重新登录或发生跳转，请重新登录；HTTP ${response.code}")
            val json = runCatching { JSONObject(text) }.getOrNull() ?: error("服务器返回的不是 JSON（HTTP ${response.code}）。请检查地址和登录状态。")
            if (!response.isSuccessful || json.optInt("code", 200) != 200) error(json.optString("msg", "请求失败：HTTP ${response.code}"))
            json
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AcgFakaApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("acg_faka_mobile", 0) }
    val scope = rememberCoroutineScope()
    var server by remember { mutableStateOf(prefs.getString("server", "") ?: "") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var captchaText by remember { mutableStateOf("") }
    var totp by remember { mutableStateOf("") }
    var captchaBytes by remember { mutableStateOf<ByteArray?>(null) }
    var loggedIn by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("服务器与登录") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("请先配置 HTTPS 地址并登录。该客户端直接调用当前 ACG-Faka 版本的后台 API。") }
    var list by remember { mutableStateOf(JSONArray()) }
    var total by remember { mutableIntStateOf(0) }
    var page by remember { mutableIntStateOf(1) }
    var versionDialog by remember { mutableStateOf(false) }

    fun runTask(block: suspend () -> Unit) {
        scope.launch {
            busy = true
            try { block() } catch (e: Exception) { message = e.message ?: "操作失败" } finally { busy = false }
        }
    }
    fun loadCaptcha() = runTask {
        prefs.edit().putString("server", server.trim().trimEnd('/')).apply()
        captchaBytes = AcgApi.captcha(server)
        message = "验证码已刷新。每次登录尝试后验证码会失效。"
    }
    fun loadModule(module: Module, newPage: Int = 1) = runTask {
        page = newPage
        val result = if (module.plugin) AcgApi.get(server, module.endpoint) else AcgApi.post(server, module.endpoint, mapOf("page" to newPage.toString(), "limit" to "15"))
        val data = result.optJSONObject("data") ?: JSONObject()
        list = if (module.plugin) data.optJSONArray("list") ?: JSONArray() else data.optJSONArray("list") ?: JSONArray()
        total = data.optInt("total", list.length())
        selected = module.title
        message = "${module.title}加载完成：当前第 $page 页，返回 ${list.length()} 条记录。"
    }
    fun togglePlugin(item: JSONObject, enabled: Boolean) {
        val id = item.optString("PLUGIN_NAME", item.optString("id"))
        runTask {
            val result = AcgApi.post(server, "/admin/api/plugin/setConfig?id=" + URLEncoder.encode(id, "UTF-8"), mapOf("id" to id, "STATUS" to if (enabled) "1" else "0"))
            message = result.optString("msg", if (enabled) "插件已启用" else "插件已停用")
            val module = modules.first()
            val response = AcgApi.get(server, module.endpoint)
            list = response.optJSONObject("data")?.optJSONArray("list") ?: JSONArray()
            total = list.length()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("异次元管理", fontWeight = FontWeight.Bold)
                    Text("ACG-Faka 原生客户端 · v$VERSION_NAME", style = MaterialTheme.typography.labelSmall)
                }
            }, actions = {
                IconButton(onClick = { versionDialog = true }) { Icon(Icons.Default.Info, contentDescription = "版本信息") }
                if (loggedIn) IconButton(onClick = { AcgApi.clearSession(); loggedIn = false; list = JSONArray(); selected = "服务器与登录"; message = "已清除本地会话，请重新登录。" }) { Icon(Icons.Default.Logout, contentDescription = "退出登录") }
            })
        },
        bottomBar = {
            NavigationBar {
                val tabs = listOf("服务器与登录", "插件管理", "订单管理", "更多模块")
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(selected = selected == tab || (tab == "更多模块" && selected in listOf("商品管理", "卡密管理", "用户管理", "操作日志", "网站设置", "版本公告")), onClick = {
                        if (tab == "更多模块") selected = "更多模块" else if (tab == "服务器与登录") selected = tab else {
                            val module = modules.firstOrNull { it.title == tab }
                            if (loggedIn && module != null) loadModule(module) else { selected = tab; message = "请先登录管理员账号。" }
                        }
                    }, icon = { Icon(when (index) { 0 -> Icons.Default.Dns; 1 -> Icons.Default.Extension; 2 -> Icons.Default.ReceiptLong; else -> Icons.Default.Apps }, contentDescription = tab) }, label = { Text(tab) })
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 14.dp)) {
            Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 8.dp)) {
                Text(message, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
            }
            when (selected) {
                "服务器与登录" -> LoginPanel(server, { server = it }, username, { username = it }, password, { password = it }, captchaText, { captchaText = it }, totp, { totp = it }, captchaBytes, busy, onRefresh = { loadCaptcha() }, onLogin = {
                    runTask {
                        prefs.edit().putString("server", server.trim().trimEnd('/')).apply()
                        try {
                            message = AcgApi.login(server, username, password, captchaText, totp)
                            loggedIn = true; password = ""; captchaText = ""; totp = ""
                            loadModuleAfterLogin { module ->
                                val res = AcgApi.get(server, module.endpoint)
                                list = res.optJSONObject("data")?.optJSONArray("list") ?: JSONArray(); total = list.length(); selected = module.title
                            }
                        } catch (e: NeedTotpException) {
                            message = e.message ?: "请输入谷歌两步验证码，并重新输入图形验证码。"
                            captchaText = ""
                            captchaBytes = AcgApi.captcha(server)
                        }
                    }
                })
                "更多模块" -> MoreModules(modules, onPick = { module -> if (loggedIn) loadModule(module) else message = "请先登录管理员账号。" }, onWebsite = { selected = "网站设置" }, onVersion = { selected = "版本公告" })
                "网站设置" -> InfoPage("网站设置", "已核对源码：/admin/api/config/setting 是 POST 保存接口，不是安全的读取接口。为避免误覆盖整站配置，这个版本先不提供盲写表单。下一步应按当前版本前端字段实现读取/编辑/校验。", Icons.Default.Settings)
                "版本公告" -> InfoPage("版本与公告", "当前源码没有移动端 bootstrap 版本策略接口。客户端已预留版本/公告模块，但需要在服务器端新增受控配置接口后，才能实现真正的强制更新与公告。不会把不存在的接口当作已完成。", Icons.Default.SystemUpdate)
                else -> {
                    val module = modules.firstOrNull { it.title == selected }
                    if (module == null) InfoPage("异次元管理", "选择一个模块开始管理。", Icons.Default.Dashboard)
                    else if (!loggedIn) LoginRequired { selected = "服务器与登录" }
                    else {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Text(selected, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            IconButton(enabled = !busy, onClick = { loadModule(module, page) }) { Icon(Icons.Default.Refresh, contentDescription = "刷新") }
                        }
                        if (busy && list.length() == 0) LinearProgressIndicator(Modifier.fillMaxWidth())
                        if (list.length() == 0 && !busy) Text("暂无数据或接口未返回列表。", modifier = Modifier.padding(12.dp))
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                            items((0 until list.length()).map { list.optJSONObject(it) ?: JSONObject() }) { item ->
                                if (module.plugin) PluginCard(item, onToggle = { enabled -> togglePlugin(item, enabled) }, busy = busy)
                                else DataCard(item, module.title)
                            }
                        }
                        if (!module.plugin) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("第 $page 页 · 共 $total 条", style = MaterialTheme.typography.labelMedium)
                            Row { OutlinedButton(enabled = !busy && page > 1, onClick = { loadModule(module, page - 1) }) { Text("上一页") }; Spacer(Modifier.width(8.dp)); Button(enabled = !busy && page * 15 < total, onClick = { loadModule(module, page + 1) }) { Text("下一页") } }
                        }
                    }
                }
            }
        }
    }
    if (versionDialog) AlertDialog(onDismissRequest = { versionDialog = false }, title = { Text("客户端版本") }, text = { Text("版本 $VERSION_NAME（$VERSION_CODE）\n原生 Kotlin + Jetpack Compose\n基于上传的 ACG-Faka 源码核对后台 API。") }, confirmButton = { TextButton(onClick = { versionDialog = false }) { Text("知道了") } })
}

private suspend fun loadModuleAfterLogin(block: suspend (Module) -> Unit) { block(modules.first()) }

@Composable
private fun LoginPanel(server: String, onServer: (String) -> Unit, username: String, onUsername: (String) -> Unit, password: String, onPassword: (String) -> Unit, captcha: String, onCaptcha: (String) -> Unit, totp: String, onTotp: (String) -> Unit, captchaBytes: ByteArray?, busy: Boolean, onRefresh: () -> Unit, onLogin: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("连接现有服务器", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(server, onServer, Modifier.fillMaxWidth(), label = { Text("服务器 HTTPS 根地址") }, placeholder = { Text("https://faka.example.com") }, singleLine = true)
        OutlinedTextField(username, onUsername, Modifier.fillMaxWidth(), label = { Text("管理员账号 / 邮箱") }, singleLine = true)
        OutlinedTextField(password, onPassword, Modifier.fillMaxWidth(), label = { Text("管理员密码") }, singleLine = true)
        OutlinedTextField(captcha, onCaptcha, Modifier.fillMaxWidth(), label = { Text("图形验证码") }, singleLine = true)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val bitmap = remember(captchaBytes) { captchaBytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() } }
            if (bitmap != null) Image(bitmap, contentDescription = "图形验证码", modifier = Modifier.height(52.dp).width(150.dp))
            else Surface(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.height(52.dp).width(150.dp)) { Box(contentAlignment = Alignment.Center) { Text("点击获取验证码", style = MaterialTheme.typography.labelSmall) } }
            OutlinedButton(onClick = onRefresh, enabled = !busy) { Text("刷新验证码") }
        }
        OutlinedTextField(totp, onTotp, Modifier.fillMaxWidth(), label = { Text("谷歌两步验证码（如启用）") }, singleLine = true)
        Button(onClick = onLogin, enabled = !busy && server.isNotBlank() && username.isNotBlank() && password.isNotBlank() && captcha.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (busy) "处理中…" else "安全登录") }
        Text("安全提示：仅支持 HTTPS；登录通过 ACG-Faka 原有认证接口，保留服务端会话和验证码校验。不要在公共设备上登录。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("如果登录失败，请先刷新验证码。账号开启两步验证时，请填写动态验证码。", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun PluginCard(item: JSONObject, onToggle: (Boolean) -> Unit, busy: Boolean) {
    val id = item.optString("PLUGIN_NAME", item.optString("id", "未知插件"))
    val name = item.optString("NAME", id)
    val desc = item.optString("DESCRIPTION", "")
    val config = item.optJSONObject("PLUGIN_CONFIG") ?: JSONObject()
    val active = config.optInt("STATUS", 0) == 1
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(name, fontWeight = FontWeight.Bold); Text(id, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                Switch(checked = active, onCheckedChange = onToggle, enabled = !busy)
            }
            if (desc.isNotBlank()) Text(desc, style = MaterialTheme.typography.bodySmall)
            Text("版本 ${item.optString("VERSION", "-")} · ${if (active) "运行中" else "已停用"}", style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun DataCard(item: JSONObject, title: String) {
    val fields = remember(item, title) { displayFields(item, title) }
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val heading = fields.firstOrNull()?.second?.takeIf { it.isNotBlank() } ?: "记录 #${item.optString("id", "-")}"
            Text(heading, fontWeight = FontWeight.SemiBold)
            fields.drop(1).forEach { (key, value) -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(key, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(0.9f)); Text(value, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1.4f)) } }
        }
    }
}

private fun displayFields(item: JSONObject, title: String): List<Pair<String, String>> {
    val candidates = when (title) {
        "订单管理" -> listOf("trade_no", "amount", "status", "delivery_status", "create_time", "contact", "commodity")
        "商品管理" -> listOf("name", "id", "price", "stock", "status", "sales", "description")
        "卡密管理" -> listOf("id", "commodity", "status", "create_time", "owner", "order")
        "用户管理" -> listOf("username", "id", "nickname", "email", "balance", "recharge", "status", "create_time")
        else -> listOf("nickname", "email", "content", "risk", "create_time", "create_ip", "id")
    }
    val result = mutableListOf<Pair<String, String>>()
    for (key in candidates) {
        if (!item.has(key) || item.isNull(key)) continue
        val raw = item.opt(key)
        val value = when (raw) {
            is JSONObject -> when { raw.has("name") -> raw.optString("name"); raw.has("username") -> raw.optString("username"); raw.has("trade_no") -> raw.optString("trade_no"); else -> "相关记录" }
            is JSONArray -> "${raw.length()} 项"
            else -> raw.toString()
        }
        val label = when (key) { "trade_no" -> "订单号"; "amount" -> "金额"; "status" -> "状态"; "delivery_status" -> "发货状态"; "create_time" -> "创建时间"; "contact" -> "联系方式"; "commodity" -> "商品"; "name" -> "名称"; "price" -> "价格"; "stock" -> "库存"; "sales" -> "销量"; "description" -> "描述"; "owner" -> "归属"; "order" -> "关联订单"; "username" -> "用户名"; "nickname" -> "昵称"; "email" -> "邮箱"; "balance" -> "余额"; "recharge" -> "累计充值"; "content" -> "操作内容"; "risk" -> "风险等级"; "create_ip" -> "操作 IP"; else -> key }
        result.add(label to value.take(180))
    }
    if (result.isEmpty()) result.add("记录" to item.optString("id", "暂无可显示字段"))
    return result
}

@Composable
private fun MoreModules(modules: List<Module>, onPick: (Module) -> Unit, onWebsite: () -> Unit, onVersion: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("管理模块", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        modules.drop(2).forEach { module -> ElevatedCard(onClick = { onPick(module) }, modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(module.icon, null); Spacer(Modifier.width(12.dp)); Text(module.title, Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null) } } }
        ElevatedCard(onClick = onWebsite, modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Settings, null); Spacer(Modifier.width(12.dp)); Text("网站设置", Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null) } }
        ElevatedCard(onClick = onVersion, modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.SystemUpdate, null); Spacer(Modifier.width(12.dp)); Text("版本与公告", Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null) } }
    }
}

@Composable
private fun InfoPage(title: String, body: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(icon, null, modifier = Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(body, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun LoginRequired(onClick: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Lock, null, modifier = Modifier.size(40.dp))
        Text("请先登录管理员账号", modifier = Modifier.padding(12.dp))
        Button(onClick = onClick) { Text("前往登录") }
    }
}
